# Task 3 - dynamic memory allocation

1. **Dynamic memory array syntax**

Repeat the dot_product and matrix_vector examples, from activities 1 and 2, using dynamic memory allocation.

2. **Comparison of stack and heap arrays**

The program `array_pointer.c` 
- illustrates some similarities between stack and heap allocated arrays
- run the code and compare to the inline comments
- will be discussed on the following slides
