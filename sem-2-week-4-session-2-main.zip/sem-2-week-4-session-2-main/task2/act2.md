# Command line arguments in C and Python



There are 2 example programs:

* cmd\_line\_args.py
* cmd\_line\_args.c



In both cases inspect the code and execute the program.



Inspect the output. What data type is argv?



Note the similarities in use of argv 

* The standard implementation of Python is in C
* Python based this feature on the existing C model.
