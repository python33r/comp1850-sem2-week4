
/* 
 * Write a program that reads in a line of text from the command line
 * 1. concatenates all the command line arguments into one string
 * 2. searches for the first occurrence of a given character
 * eg. use "The quick brown fox" on the command line and locate 'k'
 * Hint: string library functions strcat() and strcspn() can be used
 */
#include <stdio.h>
#include <string.h>

int main( int argc, char **argv ) {

    char sentence[200]="";

    /*
    Your code
    */

    return 0;
}