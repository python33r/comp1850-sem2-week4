
#include <stdio.h>
#include <stdlib.h>

/*
 * Portoflio task template
 * Full description on the worksheet
 * Your program should accept 2 integer command line arguments
 * Use the provided print statement for the only output
 */
int main( int argc, char **argv ) {

    float total = 0.0;

    // accept 2 integer command line arguments: k1 and k2

    // dynamically create an array of size k2
   
    // implement the calculation described in the worksheet

    printf("Total %.4f\n",total);

    // free any dynamically allocated memory
    
    return 0;
}
